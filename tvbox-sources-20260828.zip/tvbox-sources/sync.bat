@echo off
chcp 65001 >nul
cd /d D:\tvbox-sources

echo === 拉取线上最新内容 ===
git pull origin main
if %ERRORLEVEL% neq 0 (
    echo ❌ git pull 失败，检查网络
    pause
    exit /b 1
)

echo === 推送到 GitHub（需 gh token 认证） ===
set GH=C:\Users\tongtong\AppData\Local\Temp\gh_cli\bin\gh.exe
for /f "delims=" %%i in ('"%GH%" auth token') do set TOKEN=%%i
git push "https://jifeng250:%TOKEN%@github.com/jifeng250/tvbox-sources.git" main
if %ERRORLEVEL% neq 0 (
    echo ❌ git push 失败
    pause
    exit /b 1
)

echo ✅ 同步完成